# statistics.py

import pandas as pd

def save_statistics(run_statistics_df, run):
    """Saves the statistics for a single run to an Excel file."""


    run_filename = f"csma_ca_interference_model_run_{run + 1}.xlsx"
    run_statistics_df.to_excel(run_filename, index=False)
    print(f"Run {run + 1} statistics saved to {run_filename}")


