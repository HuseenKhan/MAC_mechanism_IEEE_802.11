# simulation.py

import pandas as pd
from .node import WLANNode, STA
from .network_topology import initialize_positions
from .utils import populate_distance_matrix, associate_stas_with_aps
from .config import NUM_NODES, NUM_STAS, TIME_SLOTS, TRANSMISSION_SLOTS, SNR_THRESHOLD, NUM_RUNS
from .statistics import save_statistics
from .config import shared_channel_status  # Explicitly import this


def determine_shared_channel_status(nodes):
    """
    Determines the shared channel status and list of currently transmitting nodes.
    """
    global shared_channel_status
    transmitting_nodes = [node for node in nodes if node.state in ["Transmit", "Waiting for ACK"]]
    shared_channel_status = "Busy" if transmitting_nodes else "Idle"
    return transmitting_nodes


def update_node_states(nodes, transmitting_nodes):
    """
    Updates each node's channel energy, channel state, and internal state.
    """
    for node in nodes:
        node.update_channel_energy(nodes)
        node.update_channel_state(nodes)
        node.update_state(nodes)


def run_simulation():
    """
    Main function to run the WLAN simulation.
    """
    all_run_statistics = []

    for run in range(NUM_RUNS):
        print(f"Starting run {run + 1} of {NUM_RUNS}...")

        # Initialize AP and STA positions
        ap_locations, sta_locations = initialize_positions()
        distance_matrix, node_ids = populate_distance_matrix(ap_locations, sta_locations)

        # Create WLAN nodes (APs) and STAs
        nodes = [WLANNode(node_id, TRANSMISSION_SLOTS) for node_id in node_ids[:NUM_NODES]]
        stas = [STA(sta_id, None, SNR_THRESHOLD) for sta_id in node_ids[NUM_NODES:]]

        # Associate STAs with APs
        associate_stas_with_aps(nodes, stas)

        # Set distances for each node based on the distance matrix
        for i, node in enumerate(nodes):
            for j, other_node in enumerate(nodes):
                if i != j:
                    node.set_distance(other_node.node_id, distance_matrix[i, j])

        # Main simulation loop over time slots
        for slot in range(1, TIME_SLOTS):
            transmitting_nodes = determine_shared_channel_status(nodes)
            update_node_states(nodes, transmitting_nodes)

            for node in nodes:
                print(f"Time Slot {slot}: Node {node.node_id} State: {node.state}")

        # Collect statistics for each node
        run_statistics = []
        for node in nodes:
            stats = node.calculate_detailed_statistics()
            if stats:  # Check if statistics were actually returned
                for stat in stats.values():
                    stat['Node ID'] = node.node_id
                    stat['STA ID'] = stat.get('STA ID', "Unknown")
                run_statistics.append(pd.DataFrame(stats.values()))
            else:
                print(f"No statistics collected for node {node.node_id}")

        # Concatenate all statistics for the run
        if run_statistics:
            run_statistics_df = pd.concat(run_statistics, ignore_index=True)
            all_run_statistics.append(run_statistics_df)
            save_statistics(run_statistics_df, run)  # Save each run’s statistics
        else:
            print("Warning: No statistics collected for this run.")

    # Save combined statistics if any data exists
    if all_run_statistics:
        save_combined_statistics(all_run_statistics)
    else:
        print("Warning: No data to save for combined statistics.")

    return all_run_statistics
