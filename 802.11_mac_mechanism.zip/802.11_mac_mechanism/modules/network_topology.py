# network_topology.py

import random
from .config import ROOMS_PER_SIDE, ROOM_SIZE, NUM_NODES, NUM_STAS

def initialize_positions():
    ap_locations, sta_locations = {}, {}
    ap_count, sta_count = 0, 0

    for i in range(ROOMS_PER_SIDE):
        for j in range(ROOMS_PER_SIDE):
            if ap_count < NUM_NODES:
                x_center = (j + 0.5) * ROOM_SIZE
                y_center = (i + 0.5) * ROOM_SIZE
                ap_locations[f"AP{ap_count + 1}"] = (x_center, y_center)

                num_stas_per_ap = NUM_STAS // NUM_NODES
                for _ in range(num_stas_per_ap):
                    sta_x = x_center + (random.random() - 0.5) * ROOM_SIZE * 0.8
                    sta_y = y_center + (random.random() - 0.5) * ROOM_SIZE * 0.8
                    sta_locations[f"STA{sta_count + 1}"] = (sta_x, sta_y)
                    sta_count += 1
                ap_count += 1
    return ap_locations, sta_locations
