# utils.py

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from .config import ROOM_SIZE, NUM_NODES, NUM_STAS


def calculate_distance(loc1, loc2):
    """Calculate Euclidean distance between two locations."""
    return np.sqrt((loc1[0] - loc2[0]) ** 2 + (loc1[1] - loc2[1]) ** 2)


def populate_distance_matrix(ap_locations, sta_locations):
    """
    Populates the distance matrix with distances between all APs and STAs.

    Parameters:
    - ap_locations (dict): Dictionary of AP IDs and their positions.
    - sta_locations (dict): Dictionary of STA IDs and their positions.

    Returns:
    - distance_matrix (ndarray): 2D numpy array with distances.
    - node_ids (list): List of all node IDs.
    """
    num_total_nodes = NUM_NODES + NUM_STAS
    distance_matrix = np.zeros((num_total_nodes, num_total_nodes))
    node_ids = [f"AP{i + 1}" for i in range(NUM_NODES)] + [f"STA{i + 1}" for i in range(NUM_STAS)]

    for i, node_id in enumerate(node_ids):
        for j, other_node_id in enumerate(node_ids):
            if i != j:
                # Get locations explicitly for APs and STAs
                loc1 = ap_locations.get(node_id) if "AP" in node_id else sta_locations.get(node_id)
                loc2 = ap_locations.get(other_node_id) if "AP" in other_node_id else sta_locations.get(other_node_id)

                # Check if locations are found
                if loc1 is None or loc2 is None:
                    print(f"Warning: Location not found for {node_id} or {other_node_id}")
                    continue  # Skip if any location is missing

                # Calculate distance if both locations are found
                distance_matrix[i, j] = calculate_distance(loc1, loc2)
    return distance_matrix, node_ids


def plot_positions(ap_locations, sta_locations):
    """Plots AP and STA positions with their boundaries for visual verification."""
    plt.figure(figsize=(8, 8))
    for (x, y) in ap_locations.values():
        bss_boundary = patches.Rectangle(
            (x - ROOM_SIZE / 2, y - ROOM_SIZE / 2), ROOM_SIZE, ROOM_SIZE,
            linewidth=1, edgecolor='black', facecolor='none', linestyle='--'
        )
        plt.gca().add_patch(bss_boundary)

    ap_x, ap_y = zip(*ap_locations.values())
    plt.scatter(ap_x, ap_y, color='blue', marker='o', label='APs')
    sta_x, sta_y = zip(*sta_locations.values())
    plt.scatter(sta_x, sta_y, color='red', marker='x', label='STAs')
    plt.legend()
    plt.show()


def associate_stas_with_aps(nodes, stas):
    """
    Associates STAs with APs based on a simple round-robin assignment.

    Parameters:
    - nodes (list of WLANNode): List of AP nodes.
    - stas (list of STA): List of STA nodes.

    Returns:
    - sta_associations (dict): Dictionary mapping STA IDs to AP IDs.
    """
    sta_associations = {}
    num_stas_per_ap = NUM_STAS // NUM_NODES
    for i, ap in enumerate(nodes):
        associated_stas = stas[i * num_stas_per_ap:(i + 1) * num_stas_per_ap]
        for sta in associated_stas:
            ap.associated_stas.append(sta)
            sta.associated_ap = ap
            sta_associations[sta.sta_id] = ap.node_id
    return sta_associations
