
from modules.config import *
from modules.simulation import run_simulation



def main():
    all_run_statistics = run_simulation()

    # Check content of all_run_statistics
    if all_run_statistics:
        for run_statistics in all_run_statistics:
            print(run_statistics.columns)  # Verify columns in each DataFrame
            print(run_statistics.head())  # Print a few rows of data
    else:
        print("Warning: No run statistics to print.")


if __name__ == "__main__":
    main()