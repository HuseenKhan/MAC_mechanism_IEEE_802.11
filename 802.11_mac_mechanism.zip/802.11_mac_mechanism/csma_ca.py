import time
import math
import random
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as patches  # Import for adding rectangles

shared_channel_status = "Idle"
class Buffer:
    def __init__(self, initial_frames=0):
        self.frames = [1] * initial_frames  # Initialize with a number of frames

    def has_frames(self):
        return len(self.frames) > 0

    def get_frame(self):
        return self.frames.pop(0) if self.has_frames() else None

    def add_frame(self):
        self.frames.append(1)


class STA:
    def __init__(self, sta_id, associated_ap, snr_threshold):
        self.sta_id = sta_id
        self.associated_ap = associated_ap
        self.received_signal_power = None
        self.noise_floor = -95  # dbm
        self.received_signal_power_noise = None
        self.interference=0
        self.SINR=None
        self.SINR_values = []
        self.snr_threshold = snr_threshold


    def receive_signal(self, transmitted_power_dbm, total_path_loss_db):
        # This method calculates the received power at the STA
        self.received_signal_power_dbm =  transmitted_power_dbm- (total_path_loss_db)


    def total_interference(self, transmitting_nodes ):

        if len(transmitting_nodes) > 1:
            total_interference_mW = node.calculate_interference(self,transmitting_nodes)


            # Convert the sum of interference back to dBm
            self.interference = 10 * np.log10(total_interference_mW)
            signal_mW = 10 ** (self.received_signal_power_dbm / 10)
            noise_mW = 10 ** (self.noise_floor / 10)
            interference_mW= 10 ** (self.interference / 10)
            sinr_mW = signal_mW / (interference_mW +noise_mW)
            self.SINR = 10 * np.log10(sinr_mW)
            self.SINR_values.append(self.SINR)

        else:
            signal_mW = 10 ** (self.received_signal_power_dbm / 10)
            noise_mW = 10 ** (self.noise_floor / 10)
            snr_mW = signal_mW / noise_mW
            self.SINR = 10 * np.log10(snr_mW)
            self.SINR_values.append(self.SINR)

    def get_minimum_SINR(self):
        # Calculate the minimum SINR from the list after transmission is completed
        if self.SINR_values:
            min_sinr=sum(self.SINR_values) / len(self.SINR_values)
            return min_sinr
        return None

    def reset_SINR_values(self):
        # Reset SINR values for the next transmission
        self.SINR_values = []

    def send_ack(self):
        min_SINR = self.get_minimum_SINR()  # Retrieve the minimum SINR value
       #print("The calculated SINR", min_SINR)
        if min_SINR is not None and min_SINR > self.snr_threshold:
            return "ACK"
        else:
            "NACK"
class WLANNode:
    CW_min = 0
    CW_max = 31
    TPC_MIN = 0  # Minimum transmission power
    TPC_MAX = 20  # Maximum transmission power
    CST_MIN = -82  # Minimum CST
    CST_MAX = -62 #Range is 10 meter

    def __init__(self, node_id, transmission_slots, associated_stas=None):
        self.node_id = node_id
        self.backoff_time = 0
        self.ifs = 1
        self.decrement_difs_count = 0
        self.deffer = 5
        self.state = "DIFS"
        self.associated_stas = associated_stas if associated_stas is not None else []
        self.current_sta_index = 0
        self.current_sta = self.get_current_sta()
        self.txop = 0
        self.metrics = {
            sta.sta_id: {'successful_transmission': 0, 'collision': 0, 'ACK': 0, 'NACK': 0, 'frame_dropped': 0,
                         'retry': 0} for sta in self.associated_stas}
        self.transmitting_nodes = []
        self.collision_occurred = False
        self.retry_occurred = False
        self.missing_txop = False
        self.buffer = Buffer(initial_frames=len(self.associated_stas))
        self.CW_current = self.CW_max
        self.time_slot = 0
        self.slot_counter = 0
        self.channel_state = "Idle"
        self.transmission_slots = transmission_slots
        self.original_transmission_slots = transmission_slots
        self.transmission_count = 0
        self.unsuccessful_attempt = 0
        self.consecutive_unsuccessful_attempt = 0
        self.CST_current = -82
        self.sensing_nodes = []
        self.prev_channel_state = self.channel_state
        self.transmission_power = 20
        self.channel_energy = -95
        self.receive_energy = None
        self.noise_floor = -95
        self.consecutive_defers = 0
        self.CWmin_TXOP = 0
        self.CWmin_successful_TX = 0
        self.do_not_transmit = 0
        self.distances = {}
        self.total_distance_to_transmitting_nodes = 0
        self.statistics = {}
        self.distances_to_transmitting_nodes = {}
        self.idle_slots = 0
        self.busy_slots = 0
        self.deffer_slots = 0
        self.backoff_slots = 0
        self.transmission_frame_slots = 0
        self.spatial_reuse = True
        self.CW_frequencies = {31: 0, 63: 0, 127: 0, 255: 0, 511: 0, 1023: 0}
        self.statistics = {}
        self.max_transmitting_nodes = 0
        self.max_transmitting_node_ids = []
        self.experienced_interference_dBm = None
        self.interference_thresholds = {}
        self.mac_off_slots = 0
        self.contention_round = 0
        self.previous_statistics = {}


    def get_current_sta(self):
        """Get the current STA to transmit to."""
        if not self.associated_stas:
            return None
        return self.associated_stas[self.current_sta_index]

    def move_to_next_sta(self):
        """Move to the next STA in the round-robin sequence."""
        if not self.associated_stas:
            return
        self.current_sta_index = (self.current_sta_index + 1) % len(self.associated_stas)
        self.current_sta = self.associated_stas[self.current_sta_index]

    def calculate_path_loss(self, sta):
        d0 = 1  # Reference distance in meters (commonly used value for indoor environments)
        PL_d0 = 40.06  # Path loss at the reference distance in dB
        n = 4.4  # Path loss exponent

        # Calculate the distance to the STA
        distance = self.get_distance(sta.sta_id)  # This will return the distance in meters
        # Apply the Log Distance Path Loss Model
        path_loss_db = PL_d0 + 10 * n * np.log10(distance / d0)
        total_path_loss_db = path_loss_db
        return total_path_loss_db

    def calculate_interference(self, sta, transmitting_nodes):
        transmitting_nodes = [node for node in nodes if
                              node.state == 'Transmit' or node.state == 'Waiting for ACK']
        # Constants for path loss calculation
        d0 = 1  # Reference distance in meters
        PL_d0 = 40.06  # Path loss at the reference distance in dB
        n = 4.4  # Path loss exponent (environment-specific)
        total_interference_mW = 0
        # Iterate through each transmitting node to calculate interference at this STA
        for node in transmitting_nodes:
            # Skip interference calculation from the STA's own associated AP
            if node.associated_stas and sta in node.associated_stas:
                continue
            # Calculate the effective distance from the transmitting AP to this STA
            effective_distance = node.get_distance(sta.sta_id)
            if effective_distance is None:
                print(f"No effective distance defined from AP {node.node_id} to STA {sta.sta_id}")
                continue  # Skip if no distance is defined
            # Calculate path loss using the Log-Distance Path Loss Model
            path_loss_db = PL_d0 + 10 * n * np.log10(effective_distance / d0)
            # Calculate interference power from this particular AP
            interference_power_dbm = node.transmission_power - (path_loss_db)
            # Convert dBm to mW and add to the total interference
            interference_mW = 10 ** (interference_power_dbm / 10)
            total_interference_mW += interference_mW

        return total_interference_mW

    def update_channel_energy(self):
        # Filter out transmitting nodes
        transmitting_nodes = [node for node in nodes if
                              node.state == 'Transmit' or node.state == 'Waiting for ACK']
        base_noise_level_dbm = -95  # dBm

        # Dictionary to store individual interference contributions from each transmitting node in dBm
        individual_interferences_dBm = {}

        # Calculate interference for the current node from each transmitting node
        for trans_node in transmitting_nodes:
            if trans_node == self:
                continue  # Skip self calculation

            # Retrieve the distance from the transmitting node to the current node
            distance = trans_node.get_distance(self.node_id)
            if distance is None:
                print(f"Distance from {trans_node.node_id} to {self.node_id} not found.")
                continue  # If distance is not found, skip this node

            # Apply the Log Distance Path Loss Model
            d0 = 1  # Reference distance in meters
            PL_d0 = 40.06  # Path loss at the reference distance in dB
            n = 4.4  # Path loss exponent
            path_loss_db = PL_d0 + 10 * n * np.log10(distance / d0)

            interference_power_dbm = trans_node.transmission_power - (path_loss_db)
            # Store the interference contribution in dBm
            individual_interferences_dBm[f"{trans_node.node_id} to {self.node_id}"] = interference_power_dbm
        # Calculate total interference in dBm from individual contributions
        if individual_interferences_dBm:
            total_interference_mW = sum(
                10 ** (interference / 10) for interference in individual_interferences_dBm.values())
            total_interference_dbm = 10 * np.log10(total_interference_mW)
        else:
            total_interference_dbm = base_noise_level_dbm

        # Assign the calculated total interference to self.channel_energy
        self.channel_energy = round(total_interference_dbm, 2)
        if self in transmitting_nodes:
            self.experienced_interference_dBm = total_interference_dbm
            self.channel_energy = base_noise_level_dbm

            return

    def distance_to_associated_sta(self):
        if self.associated_stas:
            return [self.get_distance(sta.sta_id) for sta in self.associated_stas]
        else:
            return None

    def distance_to_another_ap(self, other_ap_id):
        if other_ap_id in self.distances:
            distance = self.get_distance(other_ap_id)
            return distance
        else:
            return None

    def set_state(self, state):
        self.state = state

    def wait_for_ack(self):

        current_sta = self.current_sta
        for node in nodes:
            node.update_channel_energy()
        if current_sta:
            if self.ifs > 0 and self.state == "Waiting for ACK":
                self.ifs -= 1
                self.transmission_frame_slots += 1
            if self.ifs == 0 and self.state == "Waiting for ACK":
                ack = current_sta.send_ack()
                # Ensure metrics for current_sta are initialized
                if current_sta.sta_id not in self.metrics:
                    self.metrics[current_sta.sta_id] = {'successful_transmission': 0, 'collision': 0, 'ACK': 0,
                                                        'NACK': 0, 'frame_dropped': 0, 'retry': 0}
                if ack == "ACK":
                    self.metrics[current_sta.sta_id]['ACK'] += 1
                    current_sta.reset_SINR_values()
                    self.handle_successful_transmission(current_sta)
                    self.move_to_next_sta()  # Move to the next STA after a successful transmission
                else:
                    self.metrics[current_sta.sta_id]['NACK'] += 1
                    current_sta.reset_SINR_values()
                    self.handle_collision(current_sta)

                self.ifs = 1
                self.deffer = 5
                self.set_state("DIFS")
                self.transmission_slots = self.original_transmission_slots

    def decrement_difs(self):
        if not self.associated_stas:
            return  # No associated STAs, so no DIFS required
        if self.deffer > 0:
            self.deffer -= 1
            self.deffer_slots += 1
            if self.deffer == 0:
                self.decrement_difs_count += 1
                self.set_state("Perform carrier sense")
                self.generate_backoff()

    def set_backoff_time(self, time):

        self.backoff_time = time

    def generate_backoff(self):
        if not self.associated_stas:
            return  # No associated STAs, so no DIFS required
        if self.state == "Perform carrier sense" and self.channel_state == "Idle" and self.backoff_time == 0:
            self.set_backoff_time(np.random.randint(self.CW_min, self.CW_current))
            print(f"Node {self.node_id}: Generated backoff value: {self.backoff_time} time units")
            self.set_state("Backoff")
            if self.backoff_time == 0:
                if self.CW_current in self.CW_frequencies:
                    self.CW_frequencies[self.CW_current] += 1
                self.txop += 1

                self.state = "Transmit"
        else:
            self.state = "Backoff"
            self.consecutive_defers += 1

    def decrement_backoff(self):
        if not self.associated_stas:
            return  # No associated STAs, so no DIFS required
        if self.channel_state == "Idle" and self.state == "Backoff":
            self.slot_counter += 1
            if self.slot_counter == 1:
                print(f"Node {self.node_id}: Backoff time remaining: {self.backoff_time} time units")
                self.backoff_slots += 1
            if self.slot_counter == 2:
                if self.backoff_time > 0:
                    self.backoff_time -= 1
                self.slot_counter = 0
                print(f"Node {self.node_id}: Backoff time remaining: {self.backoff_time} time units")
                self.backoff_slots += 1
            if self.backoff_time == 0:
                for sta in self.associated_stas:
                    if self.CW_current in self.CW_frequencies:
                        self.CW_frequencies[self.CW_current] += 1
                self.txop += 1
                self.state = "Transmit"
        if self.channel_state == "Busy" and self.backoff_time != 0:
            print(
                f"Node {self.node_id}: Channel is {self.channel_state}. Node {self.node_id} pause decrementing backoff and waiting for channel to become idle...")

    def drop_frame_and_reset(self, sta):
        self.buffer.get_frame()  # Remove the frame from buffer
        self.CW_current = 31  # Reset contention window size
        self.metrics[sta.sta_id]['retry'] = 0

    def handle_collision(self, sta):
        """Handle collision-related logic for a specific STA."""
        self.metrics[sta.sta_id]['collision'] += 1
        self.collision_occurred = False
        self.metrics[sta.sta_id]['retry'] += 1
        self.retry_occurred = True
        self.CW_current = (2 * self.CW_current) + 1
        if self.metrics[sta.sta_id]['retry'] >= 7:  # Drop the frame after 6 retries
            self.metrics[sta.sta_id]['frame_dropped'] += 1
            self.retry_occurred = False
            self.drop_frame_and_reset(sta)
            self.buffer.add_frame()
            self.move_to_next_sta()  # Move to the next STA after a frame is dropped

    def handle_successful_transmission(self, sta):
        """Handle logic for a successful frame transmission for a specific STA."""
        self.metrics[sta.sta_id]['successful_transmission'] += 1
        self.retry_occurred = False
        self.metrics[sta.sta_id]['retry'] = 0
        self.buffer.get_frame()  # Remove transmitted frame from buffer
        self.buffer.add_frame()  # Add a new frame to buffer
        self.CW_current = 31

    def transmitting_frame(self):
        if not self.associated_stas:
            return  # No associated STAs, so no DIFS required
        if not self.current_sta:
            self.current_sta = self.get_current_sta()
        if self.current_sta:
            for node in nodes:
                node.update_channel_energy()

            if shared_channel_status == "Busy":
                self.slot_counter += 1
                if self.slot_counter == 1:
                    self.transmission_frame_slots += 1
                    self.transmit_to_sta(self.current_sta, transmitting_nodes)
                if self.slot_counter == 2:
                    if self.transmission_slots > 0:
                        self.transmission_slots -= 1
                        self.transmission_count += 1
                    self.slot_counter = 0
                    self.transmission_frame_slots += 1
                    self.transmit_to_sta(self.current_sta, transmitting_nodes)

                    if self.transmission_slots == 0:
                        min_SINR = self.current_sta.get_minimum_SINR()
                        self.set_state("Waiting for ACK")

    def transmit_to_sta(self, sta, transmitting_nodes):
        path_loss_db = self.calculate_path_loss(sta)
        sta.receive_signal(self.transmission_power, path_loss_db)
        sta.total_interference(transmitting_nodes)

    def update_channel_state(self):
        transmitting_nodes = [node for node in nodes if node.state in ["Transmit", "Waiting for ACK"]]

        # Determine the overall channel state
        if self.state == "Transmit" or self.state == "Waiting for ACK":
            self.channel_state = "MAC Off"
        elif self.CST_current > self.channel_energy:
            self.channel_state = "Idle"
        elif self.CST_current < self.channel_energy:
            self.channel_state = "Busy"

        # Handle transition from Busy to Idle
        if self.prev_channel_state == "Busy" and self.channel_state == "Idle":
            self.set_state("DIFS")
            self.deffer = 5
            self.channel_energy = -90

        # Update previous channel state
        self.prev_channel_state = self.channel_state

    def set_sensing_nodes(self, nodes):
        self.sensing_nodes = nodes

    def calculate_average_cwmin_txop(self, sta_id):
        """Calculate the average CWmin size per transmission opportunity for a specific STA."""
        # Extract relevant data for the STA
        total_txop = self.metrics[sta_id]['successful_transmission'] + self.metrics[sta_id]['collision']

        if total_txop > 0:
            weighted_cw_txop = sum(
                cw_size * freq for cw_size, freq in self.CW_frequencies.items() if freq > 0)
            average_cw_txop = weighted_cw_txop / total_txop
            return round(average_cw_txop / 2, 1)  # Dividing by 2 to account for the initial doubling in CW size
        else:
            return 0

    def calculate_average_cwmin_successful(self, sta_id):
        """Calculate the average CWmin size per successful transmission for a specific STA."""
        total_successful_transmission = self.metrics[sta_id]['successful_transmission']

        if total_successful_transmission > 0:
            weighted_cw_successful = sum(
                cw_size * freq for cw_size, freq in self.CW_frequencies.items() if freq > 0)
            average_cw_successful = weighted_cw_successful / total_successful_transmission
            return round(average_cw_successful / 2, 1)  # Dividing by 2 to account for the initial doubling in CW size
        else:
            return 0

    def calculate_average_defer_per_tx(self, sta_id):
        """Calculate the average number of defers per transmission opportunity for a specific STA."""
        total_txop = self.metrics[sta_id]['successful_transmission'] + self.metrics[sta_id]['collision']

        if total_txop > 0:
            return round(self.decrement_difs_count / total_txop, 1)
        else:
            return 0

    def calculate_average_defer_per_successful_tx(self, sta_id):
        """Calculate the average number of defers per successful transmission for a specific STA."""
        total_successful_transmission = self.metrics[sta_id]['successful_transmission']

        if total_successful_transmission > 0:
            return round(self.decrement_difs_count / total_successful_transmission, 1)
        else:
            return 0

    def print_cw_frequencies(nodes):
        #print("\nContention Window Frequencies and Attempt Order for each node and its associated STAs:")
        for node in nodes:
            print(f"\nNode {node.node_id} CW Frequencies:")
            for sta_id, cw_frequencies in node.CW_frequencies.items():
                attempts = list(cw_frequencies.keys())
                frequencies = list(cw_frequencies.values())
                attempt_descriptions = [f"{attempts[i]}: {frequencies[i]}" for i in range(len(attempts))]
                print(
                    f"  STA {node.node_id} CW Frequencies: {{'First Attempt': {attempt_descriptions[0]}, 'Second Attempt': {attempt_descriptions[1]}, 'Third Attempt': {attempt_descriptions[2]}, 'Fourth Attempt': {attempt_descriptions[3]}, 'Fifth Attempt': {attempt_descriptions[4]}, 'Sixth Attempt': {attempt_descriptions[5]}}}")

    def calculate_detailed_statistics(self):
        statistics = {}
        for sta_id, metrics in self.metrics.items():
            average_cwmin_txop = self.calculate_average_cwmin_txop(sta_id)
            average_cwmin_successful = self.calculate_average_cwmin_successful(sta_id)
            average_defer_txop = self.calculate_average_defer_per_tx(sta_id)
            average_defer_successful = self.calculate_average_defer_per_successful_tx(sta_id)
            cw_frequencies_details = {f"CW_{cw_size}_Freq": freq for cw_size, freq in self.CW_frequencies.items()}

            total_txop = metrics['successful_transmission'] + metrics['collision']
            statistics[sta_id] = {
                "Number of times node deferred": self.decrement_difs_count,
                "Average defer per TXOP": average_defer_txop,
                "Average defer per Successful TX": average_defer_successful,
                "Average Successful per TX": round(total_txop / metrics['successful_transmission'], 1) if metrics[
                                                                                                              'successful_transmission'] > 0 else 0,
                "Average CWmin per successful TXOP": average_cwmin_txop,
                "Average CWmin per successful Transmission": average_cwmin_successful,
                "Total successful Transmission": metrics['successful_transmission'],
                "Average defer time": average_defer_txop * 50,
                "Average backoff time ": average_cwmin_txop * 20,
                "Average access time": (average_defer_txop * 50) + (average_cwmin_txop * 20),
                "Total Collision": metrics['collision'],
                "Average Collision rate": metrics['collision'] / total_txop if total_txop > 0 else 0,
                "Total Transmission opportunities": total_txop,
                "Total frame dropped": metrics['frame_dropped'],
                "Total txOP": self.txop,
                "Node CST is": self.CST_current,
                "Node transmission power": self.transmission_power,
                "Average FER": (metrics['collision'] / total_txop) * 100 if total_txop > 0 else 0,
                "Total idle slots": self.idle_slots,
                "Total busy slots": self.busy_slots,
                "Defer slots": self.deffer_slots,
                "Transmission slots: ": self.transmission_frame_slots,
                "Backoff slots: ": self.backoff_slots,
                "Mac off slots": self.mac_off_slots,
                "Channel utilization": self.busy_slots / time_slots if time_slots > 0 else 0,
                "Contention round": self.contention_round
            }
            statistics[sta_id].update(cw_frequencies_details)
        return statistics

    def update_state(self):
        """Handles the state transitions of the node."""
        if self.state == "DIFS":
            self.decrement_difs()
        elif self.state == "Perform carrier sense":
            self.generate_backoff()
        elif self.state == "Backoff":
            self.decrement_backoff()
        elif self.state == "Transmit":
            self.transmitting_frame()
        elif self.state == "Waiting for ACK":
            self.wait_for_ack()



    @classmethod
    def update_channel_status(cls, status):
        cls.channel_status = status

    def get_node_state(self):
        return self.state

    def set_distance(self, other_node_id, distance):
        self.distances[other_node_id] = distance

    def get_distance(self, other_node_id):
        return self.distances.get(other_node_id, None)

# Simulation Parameters
NUM_RUNS = 1
NUM_NODES = 9  # Number of APs
NUM_STAS = 9  # Number of STAs
AREA_SIZE = 25  # Define the simulation area

# Calculate layout for AP and STA placement
ROOMS_PER_SIDE = int(math.sqrt(NUM_NODES))
ROOM_SIZE = AREA_SIZE / ROOMS_PER_SIDE

# Storage for all run statistics
all_run_statistics = []


# Function to initialize AP and STA positions
def initialize_positions():
    """Initializes positions for APs and STAs within a grid layout."""
    ap_locations, sta_locations = {}, {}
    ap_count, sta_count = 0, 0

    for i in range(ROOMS_PER_SIDE):
        for j in range(ROOMS_PER_SIDE):
            if ap_count < NUM_NODES:
                # AP Position
                x_center = (j + 0.5) * ROOM_SIZE
                y_center = (i + 0.5) * ROOM_SIZE
                ap_locations[f"AP{ap_count + 1}"] = (x_center, y_center)

                # STA Positions within the same room
                num_stas_per_ap = NUM_STAS // NUM_NODES
                for _ in range(num_stas_per_ap):
                    sta_x = x_center + (random.random() - 0.5) * ROOM_SIZE * 0.8
                    sta_y = y_center + (random.random() - 0.5) * ROOM_SIZE * 0.8
                    sta_locations[f"STA{sta_count + 1}"] = (sta_x, sta_y)
                    sta_count += 1
                ap_count += 1
    return ap_locations, sta_locations


# Function to plot AP and STA positions
def plot_positions(ap_locations, sta_locations):
    """Plots the AP and STA positions along with BSS boundaries."""
    plt.figure(figsize=(8, 8))

    # Plot BSS boundaries
    for (x, y) in ap_locations.values():
        bss_boundary = patches.Rectangle(
            (x - ROOM_SIZE / 2, y - ROOM_SIZE / 2), ROOM_SIZE, ROOM_SIZE,
            linewidth=1, edgecolor='black', facecolor='none', linestyle='--'
        )
        plt.gca().add_patch(bss_boundary)

    # Plot APs and STAs
    ap_x, ap_y = zip(*ap_locations.values())
    plt.scatter(ap_x, ap_y, color='blue', marker='o', label='APs')
    sta_x, sta_y = zip(*sta_locations.values())
    plt.scatter(sta_x, sta_y, color='red', marker='x', label='STAs')
    plt.legend()
    plt.show()


# Function to calculate Euclidean distance
def calculate_distance(loc1, loc2):
    """Calculates the Euclidean distance between two locations."""
    return np.sqrt((loc1[0] - loc2[0]) ** 2 + (loc1[1] - loc2[1]) ** 2)


# Function to populate the distance matrix
def populate_distance_matrix(ap_locations, sta_locations):
    """Creates and populates a symmetric distance matrix for APs and STAs."""
    num_total_nodes = NUM_NODES + NUM_STAS
    distance_matrix = np.zeros((num_total_nodes, num_total_nodes))
    node_ids = [f"AP{i + 1}" for i in range(NUM_NODES)] + [f"STA{i + 1}" for i in range(NUM_STAS)]

    for i, node_id in enumerate(node_ids):
        for j, other_node_id in enumerate(node_ids):
            if i != j:
                loc1 = ap_locations.get(node_id, sta_locations.get(node_id))
                loc2 = ap_locations.get(other_node_id, sta_locations.get(other_node_id))
                distance_matrix[i, j] = calculate_distance(loc1, loc2)
    return distance_matrix, node_ids


# Function to associate STAs with APs
def associate_stas_with_aps(nodes, stas):
    """Associates each STA with an AP in a round-robin fashion."""
    sta_associations = {}
    num_stas_per_ap = NUM_STAS // NUM_NODES
    for i, ap in enumerate(nodes):
        associated_stas = stas[i * num_stas_per_ap:(i + 1) * num_stas_per_ap]
        for sta in associated_stas:
            ap.associated_stas.append(sta)
            sta.associated_ap = ap
            sta_associations[sta.sta_id] = ap.node_id
    return sta_associations

# Main Simulation Loop
for run in range(NUM_RUNS):
    print(f"Run {run + 1}/{NUM_RUNS}")

    # Initialize positions and distance matrix
    ap_locations, sta_locations = initialize_positions()
    plot_positions(ap_locations, sta_locations)
    distance_matrix, node_ids = populate_distance_matrix(ap_locations, sta_locations)

    # Initialize nodes (APs) and STAs
    nodes = [WLANNode(node_id, 10) for node_id in node_ids[:NUM_NODES]]
    stas = [STA(sta_id, None, 15) for sta_id in node_ids[NUM_NODES:]]

    # Associate STAs with APs and print associations
    sta_associations = associate_stas_with_aps(nodes, stas)
    print("\nSTA to AP Associations:")
    for sta_id, ap_id in sta_associations.items():
        print(f"{sta_id} is associated with {ap_id}")

    # Set up distances for each AP node
    for i, node in enumerate(nodes):
        for j, other_node in enumerate(nodes):
            if i != j:
                node.set_distance(other_node.node_id, distance_matrix[i, j])
        associated_sta_ids = [sta.sta_id for sta in stas if sta.associated_ap == node]
        for associated_sta_id in associated_sta_ids:
            node.set_distance(associated_sta_id, distance_matrix[i, NUM_NODES + int(associated_sta_id[3:]) - 1])

    # Simulate transmission for all nodes
    time_slots = 200000
    for slot in range(1, time_slots):
        print(f"\nTime Slot: {slot}")
        shared_channel_status = "Busy" if any(
            node.state in ["Transmit", "Waiting for ACK"] for node in nodes) else "Idle"

        # Define transmitting nodes list once here
        transmitting_nodes = [node for node in nodes if node.state in ["Transmit", "Waiting for ACK"]]

        for node in nodes:
            node.update_channel_energy()  # Pass nodes explicitly
            node.update_channel_state()
            if node.channel_state == "Idle":
                node.idle_slots += 1
            elif node.channel_state == "Busy":
                node.busy_slots += 1
            node.update_state()  # Placeholder to represent state transitions (DIFS, Backoff, Transmit, ACK)

    # Collect and save statistics
    node_statistics = []
    for node in nodes:
        stats = node.calculate_detailed_statistics()
        for sta_id, sta_stats in stats.items():
            sta_stats['Node ID'] = node.node_id
            sta_stats['STA ID'] = sta_id
            node_statistics.append(sta_stats)

    df_run_statistics = pd.DataFrame(node_statistics)
    all_run_statistics.append(df_run_statistics)
    df_run_statistics.to_excel(f"csma_ca_interference_model_run_{run + 1}.xlsx", index=False)

# Combine and save average statistics
combined_statistics = pd.concat(all_run_statistics)
average_statistics = combined_statistics.groupby(['Node ID', 'STA ID']).mean().reset_index()
with pd.ExcelWriter("csma_ca_interference_model_average_statistics.xlsx") as writer:
    average_statistics.to_excel(writer, sheet_name="Average", index=False)

print("Simulation statistics saved to individual run files and 'csma_ca_interference_model_average_statistics.xlsx'")
